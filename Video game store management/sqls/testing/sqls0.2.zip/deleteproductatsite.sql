declare
	pidd product.pid%type;

begin
	delete from product@site_link where pid = pidd;

end;
/