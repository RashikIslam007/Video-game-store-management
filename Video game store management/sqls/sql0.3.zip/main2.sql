set serveroutput on;
declare
	x product.pname%type := 'Playstation 4';
	
begin

	searchproduct(x);

end;