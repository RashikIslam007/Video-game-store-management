declare
	x cart.cid%type := 1;
begin
	
	checkout(x);
	
end;
/