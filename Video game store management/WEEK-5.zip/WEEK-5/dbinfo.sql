
--select object_name, object_type
--from user_objects;


select object_name from user_objects
where object_type = 'PROCEDURE';










