create or replace function login(u_name varchar2, pass varchar2) return number is
declare
	un varchar2;
	up varchar2;
	yes int;
	cursor login_cur is select name, password from admi;
	

begin 
	yes := 0;
	open login_cur;
	
	loop
		fetch login_cur into un , up;
		if u_name = un && pass = un 
		then yes := 1; 
		end if;
		exit when login_cur%notfound;
	end loop;
		
	

end login;
/