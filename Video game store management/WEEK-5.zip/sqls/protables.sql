

clear screen;

DROP TABLE PRODUCT CASCADE CONSTRAINTS;
DROP TABLE CUSTOMER CASCADE CONSTRAINTS;
DROP TABLE ADMI CASCADE CONSTRAINTS;
DROP TABLE SALESRECORD CASCADE CONSTRAINTS;

CREATE TABLE PRODUCT (
	pid int, 
	price number,
	brand varchar2(10),
	stock number, 
	pname varchar2(50),
        PRIMARY KEY(pid)); 



CREATE TABLE CUSTOMER(
	cid int, 
	cname varchar2(30), 
	phone varchar2(20),
	PRIMARY KEY(cid));



CREATE TABLE SALESRECORD (
	saleid int, 
	sdate date, 
	cid int,
	pid int,
	PRIMARY KEY(saleid),
	FOREIGN KEY(cid) REFERENCES CUSTOMER(cid),
	FOREIGN KEY(pid) REFERENCES PRODUCT(pid));


 
CREATE TABLE ADMI(
	adminid int,
	name varchar2(30),
	password varchar2(10)
	);



insert into product (pid, brand, pname, price, stock) values (1, 'Sony', 'Playstation 4', 350, 50); 
insert into product (pid, brand, pname, price, stock) values (2, 'Sony', 'Playstation 4 slim', 300, 50); 
insert into product (pid, brand, pname, price, stock) values (3, 'Sony', 'Playstation 4 Pro', 450, 50); 
insert into product (pid, brand, pname, price, stock) values (4, 'Sony', 'Playstation 4', 350, 50);  
insert into product (pid, brand, pname, price, stock) values (5, 'Sony', 'PS4 Assasins Creed Origins', 50, 50); 
insert into product (pid, brand, pname, price, stock) values (6, 'Sony', 'EA Sports FIFA 18', 50, 50); 
 
insert into customer(cid,cname,phone) values(1, 'Hafizul Islam Himel', '01768532168');
insert into customer(cid,cname,phone) values(2, 'Nafis Islam', '0181923314');


insert into admi(adminid,name,password) values(1, 'sefat', '1234');




commit;
 
